# P14 · Cross-Cutting UX, Notifications, Search, Accessibility

**Read first:** `docs/06_UX_SPEC.md` (all).

## Tasks
1. **Founder & investor home polish:** Next best action card, What changed feed, Action inbox, deadline chips with absolute date + countdown and escalating tone, "Updated just now" live indicator, honest waiting states ("Waiting on the team: Finance is verifying your proof").
2. **Contact-the-right-team** component per stage (name + channel) fed by assignments.
3. **View as founder / investor** read-only preview for staff in Startup 360 / Investor 360 (uses the external views, proving parity).
4. **Command palette** (⌘K): navigate to startup/investor/deal, create note, reassign (admin). Search respects policy (no hidden fields in results or snippets).
5. **Notes with @mentions** and activity timeline on 360 pages.
6. **Notification centre:** bell, email, WhatsApp adapter; reminders T-3d/T-1d/due/overdue; preferences; quiet hours; deep links; no restricted content in subjects.
7. **Empty, loading, error states** for every list/page; skeletons; offline/reconnect banner for realtime.
8. **Accessibility:** WCAG 2.2 AA; keyboard navigation for all internal queues; focus management in modals; status never colour-only; `axe` checks in e2e.
9. **i18n-ready:** all copy in message catalogs (English populated); dates/currency via `Intl` (`en-IN`, ₹, `Asia/Kolkata`).
10. **Mobile-first** layouts verified at 360px for founder and investor portals; internal tables responsive.
11. Copy review: remove internal jargon from external screens (no "IRR scoring", "grade", "L1–L4", "analyst").

## Acceptance checklist
- [ ] axe: zero serious violations on key pages.
- [ ] "View as founder" equals the real founder payload for the same record (snapshot test).
- [ ] Lighthouse mobile performance ≥ 85 on founder home.
- [ ] Search never returns hidden fields (contract test).
