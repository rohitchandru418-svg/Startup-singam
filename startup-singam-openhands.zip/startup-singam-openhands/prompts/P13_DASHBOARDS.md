# P13 · Dashboards and Metrics

**Read first:** `docs/07_DASHBOARDS_AND_METRICS.md`, `docs/06` §4.

## Goal
Every dashboard and metric in the spreadsheet, each as a query over shared tables, with drill-down, live refresh and role scoping.

## Tasks
1. `packages/dashboards`: one SQL view / materialised view (or parametrised query) per metric. Refresh on relevant `domain_event` (debounced) and push `dashboard:{dept}` invalidation over realtime.
2. Dashboards: SR (My startups + Team view), IR (My investors + Team view), Finance (shared + work queue), Production (My shoots + Production view), Legal, Marketing, Community, Analyst queue, Management. Default landing and permission per sheet (e.g., RMs may switch to Team view read-only; reassignment only super admin).
3. Each number is a link to the filtered list that produced it (same query reused → totals always equal list length; test this).
4. Per-RM / per-IRM / per-coordinator columns; stage ageing; bottlenecks; "days stuck".
5. Finance: five fee numbers separate; overdue by age 0–15/15–30/30+ from **original** due date; Zoho failures.
6. IR compliance metrics: IRR with investors ≥2 weeks pre-shoot; thread opened ≤48h; interest conversion funnel Golden Pass → written commitment → signed → deployed.
7. Management: conversion, backlog ageing, investors, upfront fees, show readiness, money (commitments, signed deals, verified deployment), success fees, community, exceptions per department, approvals ageing vs 2 WD.
8. Export (CSV) via redaction pipeline; audited.
9. Performance: p95 < 500ms for each dashboard on seeded data ×50; indexes as needed.

## Acceptance checklist
- [ ] Every metric listed in doc 07 exists and has a test with fixtures.
- [ ] Drill-down count equals tile count for all tiles.
- [ ] A change by one role updates another role's dashboard live (e.g., Finance verifies → SR % collected changes).
- [ ] No dashboard exposes data outside role scope (policy contract tests extended).
