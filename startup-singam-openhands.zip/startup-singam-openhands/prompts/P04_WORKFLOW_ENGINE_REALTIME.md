# P04 · Workflow Engine, Clocks, Events, Realtime, Notifications

**Read first:** `docs/04` (Parts 3–4), `docs/05`.

## Goal
Make the shared data *live*: outbox dispatcher, trigger handlers T1–T19, timers/SLA, tasks/queues, notifications, and per-user realtime channels with policy-filtered invalidation messages.

## Tasks
1. **Outbox dispatcher** (pg-boss): at-least-once, idempotency key per handler, retry with backoff, dead-letter table visible to Super admin.
2. **Handlers T1–T19** exactly as in doc 04 Part 3. Each handler is a pure function + side effects through domain commands (never direct SQL). Unit-test each with the injected Clock.
3. **Timers/clocks (doc 04 Part 4):** schedule on entry, cancel on exit/resolution, recompute on policy change where safe. Implement: info-required 7d auto-Hold, analyst 5 WD escalation, MoU WD4/WD7 with restart on v2, upfront fee 15d + extension keeping original due date + ageing buckets, IRR 2-week alert, thread 48h, approvals 2 WD overdue, reminder ladder (T-3d, T-1d, due, overdue).
4. **Task / work_item service:** every actionable thing creates a `task` with assignee/department/due/source_entity; queues and "what needs me today" read from it. Provide `sla_state` computed (ok/due_soon/overdue).
5. **Realtime hub:** `GET /api/realtime` SSE; channel authorisation via policy engine; messages `{entity,id,version,changedFields}` with changedFields filtered per audience; heartbeat, reconnect with `Last-Event-ID`. Client hook `useLive(resource, id)` that invalidates cached queries and shows an "Updated just now" indicator.
6. **Notifier:** in-app notification table + email (mailhog in dev) + WhatsApp adapter stub; templates built from audience views only; record `opened_at` for thread-open tracking; user notification preferences and quiet hours.
7. **Integration test harness** that can: act as role A via command, then fetch as role B through the API, and assert payload shape. Implement scenarios **S1–S8** now (the rest land with their features).

## Acceptance checklist
- [ ] Time-travel tests (fake Clock) prove auto-hold at day 7, analyst escalation at 5 WD, fee overdue/extension logic, approval overdue at 2 WD.
- [ ] Killing the dispatcher mid-run and restarting produces no duplicate side effects.
- [ ] A realtime message to a founder never contains a field the founder cannot read (test).
- [ ] S1–S8 pass.
