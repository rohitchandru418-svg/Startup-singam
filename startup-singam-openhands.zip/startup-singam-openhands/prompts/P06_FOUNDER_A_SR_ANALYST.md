# P06 · Founder Portal (stages 0–5) + SR Workspace + Analyst Workspace

**Read first:** `docs/02` (A1, B), `docs/04` Part 1 steps 1–5, `docs/06` §2 and §4, SR sheet.

## Goal
First complete vertical: a founder registers, applies, is screened, prepared, and fit-checked — with SR and Analyst working the same records and each side seeing changes live.

## Founder portal
1. Register (one founder per startup) → Profile (company, founders, sector, stage, financials, documents). **Idea stage skips financials.** Profile reused across seasons; at new season, prefill and ask to confirm/update.
2. Application draft: sectioned form, autosave, resume, % complete + "what's missing" computed server-side from required-field rules (config), "Applications close in X days".
3. Submit → locked read-only, acknowledgement (auto), RM card with contact. Duplicate check links repeat applicants.
4. Journey stepper + Next action card + What changed feed + Action inbox (components in `packages/ui`, shared with later phases). Stages 0–5 fully derived by `deriveFounderStage`.
5. Internal review: verdict card only (label_map); Information required → exact-item checklist, per-item upload, reply-by countdown, auto-hold warning; respond submits to RM.
6. Pre-bootcamp: invite accept/decline, session dates, briefing status, action items (complete/upload).
7. Fit check: "In progress" → "Fit check done" only.

## SR workspace (My startups / Team view)
1. Landing = action queue by due date/overdue; startups by stage; follow-ups. RMs may switch to read-only Team view; reassignment is hidden for non-admins.
2. Intake: new applications, auto-assigned; completeness and document review; ack status.
3. Screening card: 100-mark card with criterion, score, comment, evidence reference per criterion (criteria list configurable); verdict with reason: Proceed / Information required (add exact items) / Hold / Reject. Show policy pass mark if set (guidance only).
4. Bootcamp: batch invites, attendance, record process briefing, readiness sessions, MoU+fee briefing, founder questions; assign action items; **Preparation complete** gate.
5. Send to analyst: one click; founder identity hidden automatically for analyst.
6. Review analyst decision: Proceed → continue to MoU (next phase UI); Conditional → condition task; Reject → final (button disabled with explanation); Hold.
7. Startup 360 tabs (Selection now; others placeholders).

## Analyst workspace
1. Single queue with due (5 WD) and overdue/escalated chips.
2. Redacted application view (banner "Founder details hidden by policy"); documents served through redaction profile; exports redacted.
3. Evaluation form: thesis fit, market opportunity, traction, business model & scalability, competitive positioning (scores + comments); willingness to invest + indicative amount (internal only, labelled "Not an investor commitment").
4. Questions for founder → creates `info_request` routed to SR (analyst cannot message founders); SR sees it, collects documents, responds.
5. Recommendation: Proceed / Conditional proceed / Hold / Reject with reason + outstanding concern → submit.

## Sync scenarios to implement as tests
S1, S2, S3, S4 (+ S20 for reassignment from this phase).

## Acceptance checklist
- [ ] Seeded founder walks stages 0→5 live while RM and analyst act in other browser contexts; founder screen updates without refresh.
- [ ] Founder never receives score/willingness/amount/analyst identity (API + realtime + notification tests).
- [ ] Analyst never receives founder name/contact anywhere including exports and document previews.
- [ ] Auto-hold after 7 days verified by time-travel e2e.
- [ ] Playwright e2e for founder, RM, analyst personas.
