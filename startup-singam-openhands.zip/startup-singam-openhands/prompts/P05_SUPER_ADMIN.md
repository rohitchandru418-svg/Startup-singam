# P05 · Super Admin / Management

**Read first:** `docs/02` (Super admin), `docs/04`, `docs/07` (Management).

## Goal
Governance backbone: approvals inbox, escalations, reassignment, policies, season setup, users and roles.

## Tasks
1. **Approvals inbox:** single list from the `approval` table; types listed in doc 02 §B; sorted by due date; overdue badge (2 WD); approve/reject **with required reason**; any one super admin may decide, recorded who/when; context panel loads the underlying entity through InternalFullView; bulk approve by type; emits events so the originating workflow continues (e.g., grade approved → investor becomes graded; IRR approved → handover).
2. **Escalations:** missed deadlines (analyst overdue, MoU negotiation, shoot-day exceptions) appear with decision form; decision recorded on the record.
3. **Reassignment:** startups ↔ RMs, investors ↔ IRMs, startups ↔ production coordinators; bulk move with workload preview; updates ownership everywhere (queues, founder/investor contact cards) and emits events.
4. **Policies (versioned, effective-dated):** screening pass mark (nullable), investor eligibility rules, fee schedule versions, working-day calendar, SLA durations, matching weights, `founder_sees_investor_identity`, `partner_share_enabled`, post-shoot signature hours. UI with diff and "effective from" date. Timers read the active version at decision time.
5. **Season setup wizard:** application window, fee schedule version, episodes (dates, slots), committee members (people records, no login), legal template versions (must be approved before "Season open"); "Season open" gate validates all prerequisites; closing/opening dates drive "Applications close in X days".
6. **Users & roles:** add staff, assign roles/departments (multi-role), deactivate; invite emails; audit all changes.
7. **Management dashboard** skeleton (metrics wired in P13) + approvals ageing widget now.

## Acceptance checklist
- [ ] Each approval type from doc 02 can be raised and decided; the downstream workflow continues after approval and halts after rejection with reason visible to the right audiences.
- [ ] Reassignment immediately changes the other user's queue and the founder/investor contact card (realtime test, S20).
- [ ] Season cannot open without approved templates, fee schedule version, committee members.
