# P10 · Upfront Fee, Finance Workspace, Production (handover → shoots) — Founder 11–14, Investor 10–11

**Read first:** Finance sheet B, Production sheet, `docs/04` rows 11–14, Founder 11–14, Investor 10–11.

## Upfront fee (Finance)
1. Request (auto from T11): turnover verification (financial year, turnover, evidence) → calculate via **fee schedule version** (placeholder DUMMY schedule; engine supports exceptions e.g. split payment/discount) → Finance lead approves standard; **Super admin approves exceptions/discounts** → invoice with due date → founder notified → sync to Zoho Books via `AccountingGateway` (mock + failure surface).
2. Founder: fee amount, turnover + FY basis, invoice download, bank details, statuses (Proof uploaded – verifying / Paid / Part paid / Overdue / Extension approved), 15-day ring, upload proof, request extension with reason.
3. Extensions: ≤7 days Finance lead; >7 days Super admin; new due date added, **original preserved**; ageing from original due date; waivers, refunds, disputes via Super admin.
4. Receipt verification: Finance checks bank evidence, allocates receipt to invoice. **Screenshot never marks paid.** Full payment → `paid` → **auto-assemble AV handover pack** (startup profile, founder contacts, selection decision, payment clearance, permitted business info) → IR approves → Production accepts.
5. Chasing: SR view-and-follow-up with late-reason recording; Finance dashboard section (doc 07) incl. Receipts to check and Zoho failures.

## Production workspace (coordinator "My shoots", head "Production view")
1. Advance notice list ("planning, fee unpaid"); handover pack inbox; acceptance.
2. **AV shoot:** story research, location, crew, schedule, founder availability, shot requirements; founder confirms availability; mark complete; save asset links.
3. **Episode allocation:** Production + IR set episode and shoot date; Production head approves; IR builds **investor panel** (grade/sector fit); 2-week IRR alert activates.
4. **Pre-shoot documentation by signing event** (not file name): requirements per event (investor commits on set; founder accepts deal).
5. **Pre-shoot confirmation (investor):** written proposed commitment, valuation boundaries, decision parameters, briefing, documents; due 2 weeks before shoot.
6. **Mock shoot:** costumes/props, pitch revisions, demo readiness, stage movement/rehearsal, final ask and valuation, open actions → Super admin final readiness approval. Founder checklist view.
7. **Main shoot:** record attendance, live ask/offers, accepted terms, lead/co-investor allocation, conditions, Investment Commitment Letter, Startup Deal Acceptance Letter, signatures done/outstanding (paper → upload). **Shoot-day exceptions** (5 types) with automatic follow-ups (SR/IR/Super admin/reshoot).
8. Post-shoot documentation window (policy, default 24h). On **deal confirmed**: T13 opens deals (IR takes over).
9. **Editing & approvals:** episode edit → head review → Super admin approval → Marketing handoff (T16).
10. Visibility: Production sees permitted business info only; investor remarks and deal documents hidden (test).

## Sync scenarios
S7, S8, S13.

## Acceptance checklist
- [ ] Uploading proof sets status "Proof uploaded – verifying", never Paid (test at API and UI).
- [ ] AV booking impossible before handover accepted; handover only after full payment verified.
- [ ] Extension keeps original due date; ageing buckets compute from it.
- [ ] Production API payloads contain no investor remarks/deal docs.
- [ ] e2e: Proceed → fee → proof → verify → pack → IR approve → Production accept → AV → mock → main with deal confirmed.
