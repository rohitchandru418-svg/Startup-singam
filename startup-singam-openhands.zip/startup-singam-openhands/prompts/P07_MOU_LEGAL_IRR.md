# P07 · MoU, Legal, IRR (Finance) — Founder stages 6–7

**Read first:** `docs/04` Part 1 steps 6–7, Legal and Finance sheets (section A), SR sheet steps 6–7.

## Goal
From Analyst Proceed to an approved Investment Readiness Report handed to IR, with founder, SR, Legal, Finance, Super admin collaborating on the same records.

## MoU
1. SR: **Share MoU** (clock starts, template version recorded); founder downloads; Legal Q&A scheduled by WD4 (calendar link field); signing deadline WD7 with countdown on founder and SR dashboards.
2. Founder responses: **Sign and upload** / **Want to negotiate (reason)** / **Not proceeding (reason)**, each with a confirmation explaining consequence.
3. SR records signed: signed copy, commercial schedule (type percentage|fixed|slab, cap, eligible vs excluded funding, upfront-adjustment-allowed), exceptions, signature date. Commercial schedule is what Finance later reads for success fee.
4. Negotiate → escalation to Super admin (approval type MoU negotiation outcome) → Legal redrafts v2 → SR shares → **clock restarts**; version history kept.
5. Discontinue → record founder email + reason; startup exits pipeline.
6. Legal workspace: queue (Q&As due, negotiations open), Q&A log, redraft tool, template manager (versions need Super admin approval), dashboard per doc 07.

## IRR
1. MoU signed → automatic IRR request (T9) → Finance accepts handover.
2. Finance sends founder the information checklist; posts **verbatim queries** with due dates; SR is cc'd and can see all; founder uploads; each query tracked to Accepted.
3. Prepare report → Finance lead review → Super admin final approval (2 WD) → every version kept → handed to IR; IR accept task.
4. Condition tasks from analyst Conditional proceed must be cleared before handover (guard).
5. 2-week rule alert (T18) data model in place (alert fires once shoot date exists).
6. Founder view: stage 7 checklist with exact queries; SR view: IRR status chips; IR view: handover inbox.

## Sync scenarios
S5, S6.

## Acceptance checklist
- [ ] Clock restart on MoU v2 proven by time-travel tests; WD4/WD7 skip holidays/weekends.
- [ ] Founder sees query text exactly as Finance typed it; SR sees same record.
- [ ] Handover blocked while a condition task is open.
- [ ] Legal template change requires approval; season cannot use unapproved version.
- [ ] e2e: founder negotiates → admin approves → v2 shared → founder signs → IRR request appears in Finance queue.
