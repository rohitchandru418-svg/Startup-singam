# P08 · Investor Portal (stages 0–4) + IR Workspace (onboarding, verification, grading, allocation)

**Read first:** `docs/02` (A2, B), IR sheet steps 1–4, `docs/06` §3.

## Investor portal
1. Express interest (short form, referred-by) → registration → login. One login per investor.
2. Profile: category and investing entity, decision-maker, authorised representative, sectors, stages, geography, thesis, ticket size, portfolio, availability, expected decision timeline. Completeness meter.
3. Agreements: Participation + NDA (**no MoU**); download template versions, sign and upload; status; sign-by date.
4. Verification: In progress / More information needed (exact items, reply-by) / Verified. **Grade never shown.**
5. Season commitment: confirm season amount and max per startup.
6. **Season meter component** (allocated · committed · deployed · available) pinned on every investor screen; formula per `docs/09 #17`.
7. Home "Needs your decision" list; derived stage via `deriveInvestorStage`.

## IR workspace (My investors / Team view)
1. New investor alert, IRM auto-assigned; referral link to Community person (no duplicates).
2. Investor record + verification: evidence collection, configurable eligibility rules engine (results per rule), reference checks, agreements tracking (Legal collaborates).
3. Grading: score each dimension with evidence, propose L1–L4 (sets permitted engagement + panel role), review date, change reason → **Super admin approval**. Internal only.
4. Season allocation: proposed allocation and max per startup, separate from commitments.
5. Investor 360: season meter, pairings, deals, tranches (empty now), announcements awaiting approval.
6. Team view: grade approvals waiting, reassignment (super admin only).

## Sync scenarios
Investor profile edit ↔ IRM queue; verification query ↔ investor checklist; grade approval ↔ matching eligibility (not visible to investor); S20 for IRM reassignment.

## Acceptance checklist
- [ ] Contract tests: no investor payload (API, realtime, email, export) contains grade or fee info.
- [ ] Matching is blocked until verification + both agreements complete + grade approved + allocation set.
- [ ] Eligibility rules are policy-driven and re-evaluated when policy changes.
- [ ] e2e: investor registers → IRM verifies → admin approves grade → investor sees "Verified" and season meter.
