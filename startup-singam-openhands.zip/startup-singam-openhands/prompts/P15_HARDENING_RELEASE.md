# P15 · Hardening, End-to-End Verification, Release

## Tasks
1. **Full-journey e2e (Playwright), multi-browser-context:** one scenario follows a startup 0→19 and an investor 0→15 simultaneously with all internal roles acting; asserts both sides see each change live and nothing forbidden ever appears. Include branches: info-required auto-hold, analyst Reject, MoU negotiate, MoU discontinue, extension request, deal withdrawal + replacement, tranche reversal, shoot-day exceptions.
2. **S1–S20** all passing as named integration tests (`sync.S01 … sync.S20`).
3. **Visibility matrix regression:** auto-generate role × resource × field tests from the policy files; fail build if any policy lacks a test.
4. **Security:** rate limits, CSRF, session hardening, optional TOTP for staff, PII/bank-detail encryption at rest, dependency audit, upload scanning hook and file-type allowlist, signed URL expiry, audit-log immutability, secret scanning.
5. **Resilience:** outbox retry/dead-letter UI; realtime reconnect; Zoho failure retry; timezone/DST-safe working-day math; idempotency across all handlers.
6. **Data:** backup/restore script, migration rollback notes, seed vs production separation, GDPR-style export/delete for personal data (policy-aware).
7. **Observability:** structured logs with request id, error reporting hook, health endpoints, admin "system" page (queue depth, failures).
8. **Docs:** update `docs/PROGRESS.md`; write `docs/RUNBOOK.md` (deploy, env vars, jobs, backups), `docs/ADMIN_GUIDE.md` (policies, season setup), and a final **Requirements Traceability Matrix** (`docs/TRACEABILITY.md`) mapping every spreadsheet row (sheet → step) to routes, commands, tests.
9. **Final report:** list unresolved items from `docs/09`, assumptions used, and recommended next steps.

## Acceptance checklist
- [ ] Traceability matrix has no unmapped spreadsheet row.
- [ ] All e2e + integration + policy tests green in CI.
- [ ] Clean-clone install and seeded demo works with documented commands.
- [ ] Final report delivered.
