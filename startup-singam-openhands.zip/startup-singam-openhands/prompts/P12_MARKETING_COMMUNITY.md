# P12 · Marketing & Telecast, Community — Founder 15 & 19, Investor 14 & 15

**Read first:** Marketing sheet (note yellow = Proposed), Community sheet, Founder 15/19, Investor 14/15.

## Marketing
1. Telecast schedule from approved episode (air date with broadcaster); founder notified (with promotion requirements) before air date; SR cc.
2. Promo assets (AV, video, posts) → **Super admin approval**; approved assets + posting brief visible to founder.
3. Founder posting: post link submission, status **Posted / Not posted** (no reach/view metrics); mark done; SR follow-up.
4. Post-telecast activity log; founder feedback (rating + text), content feedback routed to Production (feedback loop reviewed by Production head, actions logged).
5. **Public investment announcement:** draft wording from system figures labelled **announced / committed / verified deployed**; flag claims where announced ≠ deployed; **investor approves** (founder approval not needed); founder sees final published wording only. Visibility: Marketing sees approved publication info only.
6. Marketing dashboard per doc 07. Proposed features behind flag per `docs/09 #5`.

## Community
1. **Member records:** one person with multiple roles (founder + mentor + investor), organisation, sector, geography, interests, relationship owner, communication preferences/permissions, groups. Mentors and partners have no logins. Link to existing founder/investor records; never duplicate.
2. **Events:** purpose, owner, budget (Super admin approval), registrations, attendance, feedback, follow-up tasks, outcomes; types: founder meetups, investor sessions, sector roundtables, partner programmes, mentoring clinics, alumni activities. Founder/investor portals show events with join/register.
3. **Referrals:** chain interaction → referral → application/investor lead → qualified → engaged → funded/other; keep original source and later contributors separately; link to SR/IR records; investor "refer another investor" action in portal.
4. **Founder support:** request (investor intros, mentoring, customer connections, hiring, follow-on funding) with owner, deadline, outcome, founder feedback; founder portal submit/track.
5. **Hard rule:** membership never grants access to deal information (test with a person who is also investor-linked).
6. Next-season deal flow teaser for investors (non-deal-specific).

## Sync scenarios
S18, S19.

## Acceptance checklist
- [ ] Announcement cannot publish without investor approval; claim flag appears when announced ≠ deployed.
- [ ] Marketing and Community API payloads contain no deal docs/investor remarks (contract tests).
- [ ] Referral chain preserved with separate original source and contributors.
- [ ] e2e: episode approved → air date → founder posts link → feedback → routed to Production.
