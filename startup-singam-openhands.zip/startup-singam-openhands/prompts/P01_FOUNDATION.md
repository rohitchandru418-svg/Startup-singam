# P01 · Foundation

**Read first:** `AGENTS.md`, `docs/08_ARCHITECTURE_AND_STACK.md`.

## Goal
A running monorepo skeleton with database, auth shell, three app shells (founder, investor, internal), CI, and dev tooling. No business logic yet.

## Tasks
1. Scaffold pnpm + Turborepo with the layout in doc 08 (`apps/web`, `packages/{db,domain,policy,workflow,realtime,integrations,ui,dashboards}`). Reuse any existing design tokens/components in the repo for `packages/ui`; do not invent colours or fonts.
2. `docker-compose.yml`: postgres 16, minio, mailhog. `.env.example`. `pnpm dev`, `pnpm test`, `pnpm e2e`, `pnpm db:migrate`, `pnpm db:seed` scripts.
3. DB package: ORM setup, first migration with `user`, `user_role`, `audit_log`, `domain_event`, `document`. Base columns convention (id uuid, timestamps, created_by, updated_by, version).
4. Auth: credentials login + session; separate entry pages `/login` (external: founder/investor) and `/staff/login`. Password hashing with argon2. Redirect by role to `(founder)`, `(investor)` or `(internal)`.
5. App shells with navigation placeholders: founder (Journey, Inbox, Profile), investor (Home, Matches, Deals, Funds), internal (department switcher, Home, Approvals).
6. Cross-cutting libs: typed error model, request id middleware, pino logging, zod env validation, `Clock` abstraction (injectable `now()`), money util (`numeric(18,2)` ↔ decimal string).
7. CI workflow: lint, typecheck, unit, e2e smoke.
8. `docs/PROGRESS.md` initialised.

## Acceptance checklist
- [ ] `docker compose up -d && pnpm i && pnpm db:migrate && pnpm dev` works from a clean clone.
- [ ] Founder, investor and staff test users can log in and land on the correct shell; wrong-role route access returns 403.
- [ ] Audit log and domain_event tables exist with a unit test that a sample command writes both in one transaction (rollback test included).
- [ ] CI green.
