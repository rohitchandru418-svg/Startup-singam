# P02 · Identity, RBAC, Visibility (Policy) Engine, Audit

**Read first:** `docs/02_PERSONAS_AND_PERMISSIONS.md`, `docs/05_SHARED_DATA_AND_SYNC.md`.

## Goal
The security heart of the product: roles, a declarative field-level visibility engine, redaction, label mapping, stage derivation scaffolding, and audited document access. Everything later depends on this.

## Tasks
1. **Roles:** enum `SUPER_ADMIN, SR_RM, ANALYST, IR_MANAGER, FINANCE, FINANCE_LEAD, PRODUCTION_COORDINATOR, PRODUCTION_HEAD, LEGAL, MARKETING, COMMUNITY` plus external `FOUNDER`, `INVESTOR`. Users may hold multiple roles. Add `person` and `organisation` tables (one person, many roles).
2. **Ownership scopes:** founder owns exactly one startup; investor owns exactly one investor record; RM/IRM/coordinator scoped to assigned records (with team-view read-only escalation for RMs/IRMs); Super admin all.
3. **Policy engine** in `packages/policy`:
   - Declarative rules: `{resource, field, audience, condition, effect: allow|redact|deny}` loaded from code-defined policy files (version-controlled) that encode the matrix in doc 02 §C.
   - Audience views: `FounderView, InvestorView, AnalystView, ProductionView, MarketingView, CommunityView, InternalFullView` as serializers per resource.
   - Row filters for list queries (e.g., investor sees committee result only for startups they showed interest in).
   - Helpers: `redactFounderIdentity()` for Analyst (names, emails, phones, LinkedIn, addresses, in text blobs too via configured fields), export redaction pipeline.
4. **label_map** (single config) for internal→external labels (doc 02 §A1). `deriveFounderStage` / `deriveInvestorStage` as interfaces with stubs returning the first stage; later phases fill in.
5. **Document access:** `document` table with `classification` and `redaction_profile`; signed, audited download endpoint that re-checks policy; IRR "view-only" streaming mode flag (no download link) with watermark hook.
6. **Audit:** every command logs actor, role used, entity, before/after (policy-filtered for display), reason when required. Admin audit viewer (Super admin only).
7. **Contract tests (mandatory):** a table-driven suite `role × resource × field` asserting each cell of the doc 02 matrix. Also tests: analyst export contains no founder name/email/phone; investor payloads never contain `grade`; founder payloads never contain `score`, `willingness`, `indicative_amount` from analyst; production payloads exclude investor remarks and deal documents; community cannot read any deal entity even if the person is also an investor/founder in another role context.

## Acceptance checklist
- [ ] Policy contract suite covers every cell of the matrix and passes.
- [ ] No API in the repo returns raw table rows to a client (lint rule or test proving all go through views).
- [ ] Signed download denies when policy denies; logs allow/deny.
- [ ] Redaction works inside free-text fields and exports.
