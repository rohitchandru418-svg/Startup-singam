# P11 · Deal Closure, Due Diligence, Tranches, Success Fee, Reconciliation — Founder 16–18, Investor 12–13

**Read first:** IR sheet 13–15, Legal sheet 4–6, Finance sheets C–D, `docs/05` S14–S17.

## Deal closure (IR-owned, one accountable IRM per deal)
1. Deal created per investor on deal confirmed. Open communication thread (email/WhatsApp stays external) within **48h**; system records opened-at; countdown on investor deal room; breach shows in IR compliance.
2. Milestones: term sheet, DD, findings resolved, definitive agreements (SHA/SSA etc.), pre-funding conditions (e.g., IP assignment, board resolution), funding. Expected date per milestone; blocker, owner, next action.
3. **Legal runs DD inside the deal:** request docs from founder, review, log findings with severity, track to resolution. Finance does not do DD. External advisors recorded as participants without login.
4. Agreements: drafting + signature tracking; pre-funding conditions tracked; IR confirms; transfer allowed only when conditions met.
5. **Revisions/withdrawals** need a reason and **Super admin approval**; withdrawal triggers replacement-investor search and shows founder reason/replacement activity.
6. Founder "Deal closure" card per investor; investor "Deal room" per startup (doc 02). SR follow-up tasks for founder items.

## Funds (tranches)
1. Schedule tranches (amount, date). Investor marks sent (UTR + proof) or IRM records on their behalf; founder confirms receipt + bank statement; **Finance verifies** with bank/approved evidence recording verified amount, date, verifier, remaining commitment.
2. Reversal links to original: reduces deployed and fee base; credit note if already invoiced.
3. Season meter and "deployed" update on verified only; commitments vs reported vs verified shown separately for Finance.
4. Founder "Funds received" and investor "Fund transfers" steppers per doc 02.

## Success fee (Finance)
1. Verified tranche → auto task (T14). Fee read from MoU commercial schedule: percentage / fixed / slab, cap, eligible vs excluded funding, upfront adjustment **only if agreement allows**, discounts, waivers; partner share field exists, off by default.
2. Lead reviews → **one invoice per verified tranche** → Zoho sync → founder notified (base, rate, invoice).
3. Founder pays net, enters TDS deducted, uploads proof; Finance allocates cash + TDS (screenshot never marks paid). Form 16A upload + reminders until received.
4. Reconciliation: balance startup account (upfront charges, success fees, receipts, GST, TDS, credits, optional partner settlements); close only when balanced and TDS certificates in.
5. Five fee measures shown separately everywhere (Forecast, Due, Invoiced, Collected, Outstanding).
6. SR/IR follow-up chasing views.

## Sync scenarios
S14, S15, S16, S17.

## Acceptance checklist
- [ ] Success fee calculated only from verified money; reversal adjusts base and creates credit note when needed (fixtures for percentage, fixed, slab with cap).
- [ ] Fund transfer cannot be marked verified without Finance action; investor report and founder confirmation alone leave it "pending verification".
- [ ] Commitment revision/withdrawal blocked until Super admin approves; founder sees reason afterwards.
- [ ] 48h thread breach flagged; deals-by-stage shows days stuck.
- [ ] e2e: multi-tranche deal with one reversal, invoices, TDS, Form 16A, reconciliation closes.
