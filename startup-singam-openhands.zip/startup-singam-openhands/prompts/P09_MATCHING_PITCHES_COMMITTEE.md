# P09 · Matching, Virtual Pitch, Pitch Day, Committee

**Read first:** `docs/04` Part 2 steps 5–9, IR sheet steps 5–10, Founder stages 8–10, Investor stages 5–9.

## Goal
The two-sided marketplace core: IRR → matches → pitches → verdicts → Pitch Day → Golden Pass → committee → automatic triggers on Proceed.

## Tasks
1. **Matching engine:** suggest investors per startup using sector, stage, cheque size, geography, thesis, grade, unused allocation; weights from policy. Persist `match_score` + dimension breakdown. **IRM approves circulation**; 5–6 per investor; flag startups with <3 matches. Each pairing is its own record (all fields in doc 03).
2. **Investor side:** matches list with match %, in-page **IRR reader** (versioned, dated, **no download/print**, watermark), ask question, request document, indicative amount, accept/decline.
3. **Founder side:** "Matched with N investors", slot picking, per-investor verdict chips, info-request answers.
4. **Virtual pitch:** IRM schedules (5 min pitch + 5 min Q&A); investor approves slot; attendance, material, Q&A, minutes with acknowledgement by investor and founder; **verdict** entered by investor or by IRM on behalf (records who entered): Ready to invest / Next stage / Information requested / Pass / No response. "Ready to invest" opens the indicative form (amount, valuation range, instrument, conditions) with permanent **Indicative** label; stored in `ready_to_invest_form`, never in `commitment`.
5. **Pitch Day:** map startups to investors; IRM proposes slots → investor approves → founder books (only approved slots selectable); distribute IRR + information memorandum; outcomes; **Golden Pass** (issuer, no minimum commitment), written commitments, HNI follow-on interest with deadlines — recorded by IR team.
6. **Committee pack:** auto-compile snapshot (evaluation, IRR, investor feedback, Golden Passes, unresolved questions, proposed investor participation, production readiness, commercial status). IR records decision: Proceed / On hold / Rejected with conditions, approver, decision date, re-review date.
7. **Visibility:** founder sees committee result via label_map; investor sees result only for startups they showed interest in; analyst scores never appear.
8. **Automatic on Proceed (T11):** create upfront fee request + 15-day clock, Production advance notice, notify SR — no manual step.
9. SR lifecycle "Selection" tab and dashboards counters (Pitches, Committee).

## Sync scenarios
S9, S10, S11, S12.

## Acceptance checklist
- [ ] Investor cannot download an IRR by any route (UI, API, print CSS, direct file URL).
- [ ] Indicative amounts never contribute to committed totals or the season meter.
- [ ] Founder cannot book a slot the investor has not approved.
- [ ] Recording Proceed creates fee request, advance notice and SR notification exactly once (idempotency test).
- [ ] e2e: full chain match → pitch → verdict → pitch day → Golden Pass → committee Proceed with both external users watching live.
