# P03 · Domain Schema, State Machines, Commands, Seed

**Read first:** `docs/03_DOMAIN_MODEL.md`, `docs/04_WORKFLOWS_END_TO_END.md`.

## Goal
Implement the complete shared schema and the transition logic that guards every workflow, plus realistic seed data for all personas. No UI beyond admin inspection.

## Tasks
1. Migrations for every table in doc 03 sections 1–6 (policy/season, startup side, investor side, money, production/marketing, cross-cutting, community). Add indexes for queue queries (`assignee`, `due_at`, `status`), unique constraints (one founder login per startup, one pairing per investor+startup+season, one success fee per tranche, one open handover pack per startup+season).
2. `packages/domain`: a small state-machine helper (`defineMachine({states, transitions, guards, onEnter})`) and a machine per entity in doc 03 §7. Guards encode business rules, e.g.:
   - Analyst REJECT is terminal; SR command `continueToMou` throws when analyst recommendation is REJECT.
   - `startAvShoot` requires `upfront_fee.status=paid` (via verified receipt) and accepted handover pack.
   - Upfront fee `markPaid` callable only from `verifyReceipt` command with bank evidence; `uploadPaymentProof` never changes status to paid.
   - `commitment` is separate from `indicative_amount`; indicative values can never be summed into "committed".
   - Success fee created only from verified tranche; `base = verified_amount net of reversals`.
3. Commands (one function each) with signature `(ctx: {actor, role, now}, input) → {entity, events[]}` and common wrapper: authorise → guard → write → audit → outbox in one transaction. Cover every action named in docs 02 and 04 (hundreds of small commands—generate by workflow area, keep file per area: `startup`, `screening`, `bootcamp`, `analyst`, `mou`, `irr`, `investor`, `grading`, `allocation`, `pairing`, `meeting`, `verdict`, `committee`, `fee`, `shoot`, `deal`, `tranche`, `success_fee`, `marketing`, `community`, `approval`).
4. Working-day calendar service (`addWorkingDays`, `workingDaysBetween`) backed by `policy.working_day_calendar`; seed Indian holidays placeholder.
5. Computed fee views: `forecast_fee, fee_due, invoiced, collected, outstanding` as SQL views with tests using fixtures including TDS, reversal, extension (original due date preserved).
6. **Seed data** (`pnpm db:seed`): 1 season; staff for every role; 12 startups spread across every stage (0–19) including one idea-stage, one auto-held, one conditional proceed, one MoU negotiate, one withdrawn deal; 8 investors across statuses with grades L1–L4; pairings in all verdict states; deals with multi-tranche funding incl. one reversal; sample documents (dummy files); a DUMMY fee schedule clearly labelled.
7. Unit tests: every transition table (valid and invalid transitions), guards above, working-day math, fee views.

## Acceptance checklist
- [ ] All tables migrated; seed produces the 12 startups at the specified stages.
- [ ] Invalid transitions throw typed errors; tests prove SR cannot override analyst Reject, screenshot cannot mark paid, indicative ≠ commitment.
- [ ] Each command writes audit + outbox atomically.
