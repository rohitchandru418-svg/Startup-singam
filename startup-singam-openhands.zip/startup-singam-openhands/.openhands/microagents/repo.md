---
name: startup-singam-repo
type: repo
version: 1.0.0
agent: CodeActAgent
---

# Startup Singam — repository rules for OpenHands

Read `docs/01`–`docs/09` before coding. The spreadsheet `Startup_Singam_2__1_.xlsx` is the source of truth; the docs are its structured translation.

## Hard rules
1. **One database, one writer.** All mutations go through `packages/domain` commands. UI/API handlers never write tables directly.
2. **Visibility is server-side.** Use `packages/policy` views for every read, export, file download, notification and realtime payload. Never hide data only in React.
3. **External stage names are derived** from internal state (`deriveFounderStage`, `deriveInvestorStage`) using `label_map`. Never store founder-facing stages.
4. **Every state change** = transaction { mutate + audit_log + domain_event (outbox) }.
5. **Realtime payloads are invalidation messages**, not data. Clients refetch through the policy-filtered API.
6. Never expose: investor grade, screening score to founder, analyst data to founder, founder identity to analyst, fees to investors.
7. Money = `numeric(18,2)`; fee measures (forecast/due/invoiced/collected/outstanding) are views.
8. A payment proof or screenshot never sets `paid`. Only Finance receipt verification does.
9. Do not implement colours/typography: use existing design tokens/components.
10. Every phase ends with: migrations applied, tests green (`pnpm test`, `pnpm e2e`), seed data updated, and `docs/PROGRESS.md` updated (done / assumptions / open items).

## Working method
Plan → implement smallest vertical slice → test → commit with conventional message. Prefer config/policy over hard-coded constants (see `docs/09_OPEN_QUESTIONS.md`). If the spreadsheet is silent, pick the documented assumption and log it.
