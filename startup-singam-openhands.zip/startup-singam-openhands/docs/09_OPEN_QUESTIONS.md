# 09 · Assumptions, Gaps and Open Questions

Build with the **assumption** shown; keep each one behind a policy/config so it can change without code changes.

| # | Gap in spreadsheet | Assumption used | Where configurable |
|---|---|---|---|
| 1 | Screening **pass mark** "not set yet" | None enforced; RM decides, score is guidance | `policy.screening_pass_mark` (nullable) |
| 2 | **Fee schedule** "still to be supplied" | Engine supports tiers by turnover band, versioned; seed a placeholder schedule clearly marked DUMMY | `fee_schedule_version` |
| 3 | Post-shoot signature window "same day / 24h (to confirm)" | 24h | `policy.post_shoot_signature_hours` |
| 4 | Episode final approval "proposed: super admin" | Production head reviews → Super admin approves | approval type config |
| 5 | Marketing yellow rows = **Proposed** | Build, but flag as "proposed" in config; easy to disable | feature flag |
| 6 | Community has **no SOP**; v1 from proposed module | Build as specified in the sheet | — |
| 7 | Investor journey lists Agreements (2) before Verification (3); IR does verification then agreements | Both are parallel prerequisites; matching requires both | workflow config |
| 8 | What investor-identity info founders see in matches | Founder sees investor **display name + category** only; no grade, no remarks, no amounts | `policy.founder_sees_investor_identity` |
| 9 | What founder info investors see | Business information from IRR + approved pitch content; founder contacts shared only after a deal is confirmed | policy |
| 10 | Committee members: login? | No login v1; IR records decisions with approver, date, conditions | — |
| 11 | Outside legal firm login | Deferred; build role hook only | — |
| 12 | Partner share in success fee | Field exists, **off by default** | `policy.partner_share_enabled` |
| 13 | Match % formula | Weighted: sector, stage, ticket, geography, thesis, grade, unused allocation; weights configurable | `policy.matching_weights` |
| 14 | Eligibility rules for investors | Policy-driven rules list (e.g., min ticket, entity type); engine only | `policy.investor_eligibility` |
| 15 | Communication thread | System **records** that a thread was opened/when; chat itself stays on email/WhatsApp | — |
| 16 | Founder "one per startup" | Single founder login; additional co-founders exist as people records without logins | — |
| 17 | Season-meter "available" | `allocated − committed − deployed`? (committed already includes deployed) → define as `allocated − max(committed, deployed)`; confirm with business | formula in `packages/domain` |
| 18 | Working-day calendar | India national holidays seed, editable by Super admin | `policy.working_day_calendar` |
| 19 | Currency/tax | INR; GST and TDS entries tracked, not computed beyond configured rates | policy |

**Do not block** on these. Implement defaults, surface them in an `Admin → Policies` screen, and list unresolved items in the final report.
