# 06 · UX Specification (behaviour and information design — visual styling is supplied separately)

> Visual design system (colours, typography) is **out of scope**; use whatever tokens exist in the repo. This doc defines structure, interaction and content.

## 1. UX principles
1. **Answer four questions on every screen:** Where am I? What do you need from me? By when? Who do I contact?
2. **One next action.** Each persona's home leads with a single "Next best action" card, then the rest.
3. **Never make people re-enter data.** Profile reused each season; deal/startup facts pre-filled everywhere.
4. **Plain language outside, precision inside.** Founders never see internal jargon (IRR scoring, grade, L1–L4, analyst).
5. **Show waiting honestly.** "Waiting on the team" states say who and what, never imply the user must act.
6. **Live, not stale.** When the other side changes something, show a subtle "Updated just now" and update in place; never silently reorder what the user is reading.
7. **Deadlines are first-class:** every deadline renders as chip with absolute date + countdown ("Due 22 Nov · 6 days"), tone escalates when ≤2 days/overdue.
8. **Mobile-first for external users; dense, keyboard-friendly for internal users.**
9. **Trust cues for money:** always label *indicative / committed / deployed / verified*; never show a bare "amount".
10. **Accessible:** WCAG 2.2 AA, focus management, screen-reader labels, status never colour-only, i18n-ready strings (English first, no hard-coded copy).

## 2. Founder portal
**Home** = Journey header + Next action card + Parallel tracks.
- **Journey stepper:** 20 stages; completed / current / upcoming / not applicable (e.g., Idea stage skips financials). After the main shoot, split into two lanes: *Telecast* and *Deals → Funds → Success fee*.
- **Next action card:** title, what's needed, deadline chip, contact (name + email/phone of RM), primary button.
- **"What changed" feed:** latest team updates in plain words (e.g., "Your MoU is ready to download").
- **Action inbox:** all open founder tasks from every stage, sorted by due date.
- Stage-specific design:
  - *Profile/Application:* sectioned form with autosave, % complete ring, "what's missing" list linking to the field; submit disabled until 100%; after submit, read-only + acknowledgement + RM card.
  - *Internal review:* verdict card only; Information required → exact-item checklist with upload per item and reply-by countdown; auto-hold warning at day 5.
  - *MoU:* download, Legal Q&A date (WD4) with join link, WD7 countdown; three choices (Sign & upload / Want to negotiate / Not proceeding) each with required reason; confirmation modals explaining consequences.
  - *Document scrutiny:* checklist of team queries, verbatim, each with due date, upload, status (Open / Submitted / Accepted).
  - *Matching & pitches:* "Matched with N investors" cards (investor display name only as policy allows), slot picker, per-investor verdict chips, info-request responses.
  - *Upfront fee:* fee breakdown (amount, turnover, FY basis, schedule), invoice download, bank details copy buttons, status timeline (Proof uploaded – verifying → Paid), extension request with reason, 15-day ring. Explain "screenshot ≠ paid".
  - *Shoots:* date/location/prep list; availability confirm; mock readiness checklist with progress.
  - *Main shoot:* accepted offers, lead/co split, conditions, signing tracker (signed/outstanding).
  - *Deals:* one card per investor with milestone timeline and expected dates; DD upload tasks; replacement-investor banner.
  - *Funds:* per investor tranche table: committed / reported / received / pending; confirm receipt + bank statement.
  - *Success fee:* invoice per tranche; base/rate/TDS entry; Form 16A upload reminders.
- **Help:** persistent "Contact my RM" with the right team per stage.

## 3. Investor portal
- **Sticky season meter** (allocated · committed · deployed · available) on every screen, with tooltip definitions.
- **Home:** "Needs your decision" list (matches to respond, verdicts due, slots to approve, announcements to approve, tranches to mark), then pipeline by stage.
- **Matches:** 5–6 cards with match % and dimension breakdown (sector, stage, ticket, geography); IRR reader opens in-page (no download); accept/decline with optional reason.
- **IRR reader:** version + date shared, ask question, request document, give indicative amount; watermark.
- **Pitch scheduling:** approve proposed slots with one tap; minutes acknowledgement.
- **Verdict form:** five choices; *Ready to invest* expands to amount, valuation range, instrument, conditions with persistent "Indicative — not a commitment" label.
- **Deal room** (per startup): thread status + 48h countdown, term sheet, DD progress bar with resolved findings count, agreements, pre-funding conditions, expected dates, revision/withdrawal request (reason required, shows "Pending approval").
- **Fund transfers:** per tranche stepper (Scheduled → You reported → Startup confirmed → Verified) with UTR + proof upload.
- No fees anywhere. No grade anywhere.

## 4. Internal workspaces (shared patterns)
- **Home = "What needs me today":** action queue sorted by due date with overdue on top, SLA chips, saved filters, bulk actions.
- **Startup 360 / Investor 360 / Deal 360** pages: header (stage, owner, next action, blocker), tabs by track (Selection, Production, Investment, Finance, Marketing), notes with @mentions, activity timeline, "view as founder/investor" preview (read-only) so staff see exactly what the external user sees.
- **Command palette (⌘K):** jump to startup/investor/deal; create note; reassign.
- **Inline decisions:** verdict/approve/reject in-place with required reason field.
- **Redaction banner** (Analyst/Production/Marketing): "Founder details hidden by policy" so gaps don't look like bugs.
- **Empty states** state what unlocks the work ("Waiting for founder's upfront fee").
- **Role dashboards** per doc 07 metrics; click any number to open the filtered list that produced it.
- **Approvals inbox** (Super admin): sort by due; overdue badge; approve/reject with reason; item context panel with all evidence; bulk approve for same type.

## 5. Notifications
In-app bell + email (+ WhatsApp adapter). Reminders at T-3d, T-1d, due, overdue. Each notification deep-links to the exact task. Quiet hours configurable. Never leak restricted content in subject lines.
