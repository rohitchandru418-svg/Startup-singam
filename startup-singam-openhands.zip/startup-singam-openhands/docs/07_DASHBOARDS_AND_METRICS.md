# 07 · Dashboards and Metrics (per spreadsheet)

Every metric is a **query over shared tables** (SQL view or materialised view refreshed on events). Clicking a number opens the underlying list. Each dashboard has **My view** (act) and **Team view** (oversee).

## Startup Relations
- **My startups** (RM landing): action queue by due date/overdue; startups by stage; my follow-ups; my numbers for all metrics below.
- **Team view** (Super admin default; RMs read-only): same metrics + per-RM column (workload, overdue, conversion), stage ageing, bottlenecks; **reassign (super admin only)**.
- Metrics: Intake (new, acknowledgements pending, awaiting RM) · Screening (screened, waiting, Proceed/Info required/Hold/Reject, auto-held after 7d) · Bootcamp (invites not sent, briefings not done, prep complete) · Analyst (sent, waiting, Proceed/Hold/Reject) · MoU (shared, Q&A done, signed, negotiating, discontinued, past day 7) · IRR (requested, in progress, documents missing, approved, handed to IR, at risk of 2-week rule) · Pitches (in virtual, in Pitch Day, Golden Passes) · Committee (approved/on hold/rejected) · Upfront fee (% collected of determined, not collected, overdue) · Shoots (AV/mock/main done vs pending) · Success fee (% collected, not collected, overdue) · Promotion (posted vs pending, feedback) · Workload (overdue per RM).

## Investor Relations
- **My investors** (IRM landing): queue; my investors + season meters; pairings by stage; deals by closure stage.
- **Team view:** per-IRM column; grade approvals waiting; commitment changes waiting; reassignment (super admin only).
- Metrics: Investors (verified; agreements pending; pipeline sourced→verified→graded→active) · Grades (distribution L1–L4; approvals waiting; reviews due) · Capital (unallocated; per investor allocated vs committed vs deployed) · Matching (coverage; startups with <3 matches; accept/decline rate) · Pitches (unanswered; verdict mix per round; avg response time) · Interest conversion (Golden Pass → written commitment → signed → deployed) · Compliance (IRR with investors 2 weeks pre-shoot; thread opened ≤48h) · Deals (outstanding commitments; at risk; by closure stage with days stuck; revised; withdrawals awaiting replacement) · Workload (overdue per IRM).

## Finance (one shared view + work queue)
Work queue · IRR (requested, accepted, docs missing, in review, awaiting super admin, approved, at risk 2-week) · Upfront fee (determined vs collected vs outstanding; overdue by age 0–15/15–30/30+ from original due date; extensions; disputes; waivers) · Receipts to check (upfront + success) · Deployment (committed vs investor-reported vs verified; tranches awaiting verification; reversals) · Success fee (forecast, due, invoiced, collected, outstanding; overdue; due-not-invoiced) · Reconciliation (unbalanced accounts; TDS certificates pending; GST entries) · System (Zoho Books sync failures).
**Five fee numbers always separate:** Forecast · Due · Invoiced · Collected · Outstanding.

## Production
- **My shoots** (coordinator): startups by shoot stage, shoot calendar, founder availability pending, signatures outstanding.
- **Production view** (head + super admin): per-coordinator workload, readiness approvals waiting.
- Metrics: Pipeline (paid startups awaiting AV; advance notices with fee unpaid) · Handovers (awaiting IR approval / Production acceptance) · AV (completion; assets uploaded vs pending) · Mock (readiness; approvals waiting) · Documents (missing; signatures past deadline) · Episodes (allocation; calendar) · Exceptions by type · Founders (availability pending) · Content (episodes in editing/awaiting approval; feedback received vs actioned).

## Legal (one shared view + work queue)
MoU (Q&As due by day 4; negotiations open) · Due diligence (deals in DD; open findings by severity; days in DD) · Agreements (awaiting drafting/signature) · Conditions (pre-funding outstanding; deals blocked by Legal).

## Marketing
Episodes (scheduled, aired, upcoming air dates) · Founders (notified vs pending) · Assets (awaiting approval, approved) · Posting (completion %) · Feedback (received, average rating, routed to Production) · Announcements (drafts awaiting investor approval; claims flagged where announced ≠ deployed).

## Community
Participation (active members; repeat attendance) · Partners (activity) · Referrals (qualified; funding linked to community) · Support (resolved vs open).

## Analyst
Single queue: assigned, due in N WD, overdue, submitted. Redacted at all times.

## Management (Super admin)
Conversion (application→selection) · Backlog (stage-wise + ageing) · Investors (engagement + conversion) · Upfront fees (due/collected/overdue) · Show (shoot + telecast readiness) · Money (commitments, signed deals, verified deployment) · Success fees (due/invoiced/collected/overdue) · Community (activity/outcomes) · Exceptions (department-wise overdue + material exceptions) · Approvals (waiting + ageing vs 2-WD deadline).
