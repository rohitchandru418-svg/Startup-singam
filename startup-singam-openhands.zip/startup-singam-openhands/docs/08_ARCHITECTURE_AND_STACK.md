# 08 · Architecture and Stack (defaults — override only if the repo already dictates otherwise)

| Concern | Default |
|---|---|
| Language | TypeScript everywhere |
| Monorepo | pnpm workspaces + Turborepo |
| Web | Next.js (App Router) — three route groups: `(founder)`, `(investor)`, `(internal)` sharing one component library; internal workspaces are sub-routes per department |
| API | Next.js route handlers or a separate Fastify service exposing a typed command/query API (tRPC or OpenAPI + zod). All mutations go through `packages/domain` |
| DB | PostgreSQL 16 + Prisma (or Drizzle) migrations; Row-level security optional second line of defence |
| Auth | Auth.js (credentials + magic link), argon2, session cookies, optional TOTP for staff; role claims; separate login pages for external vs internal |
| Jobs / clocks | pg-boss (Postgres-based; no Redis): working-day timers, reminders, SLA escalation, auto-hold, outbox dispatch |
| Realtime | SSE endpoint + Postgres LISTEN/NOTIFY fan-out (single process) — abstract behind `RealtimeHub` |
| Files | S3-compatible (MinIO locally) with signed URLs through audited endpoint |
| Email / WhatsApp | `Notifier` interface; SMTP/Resend adapter; WhatsApp adapter stub (log-only) |
| Accounting | `AccountingGateway` interface; Zoho Books adapter + mock; sync status + retry + failure surface in Finance dashboard |
| Tests | Vitest (unit), Playwright (e2e per persona), contract tests for policy engine |
| Dev | docker-compose (postgres, minio, mailhog); `pnpm dev`; seed script with demo data for all personas |
| Observability | pino logs, request ids, audit log UI |

## Suggested layout
```
apps/web                 # Next.js: (founder) (investor) (internal)/{sr,analyst,ir,finance,production,legal,marketing,community,admin}
packages/db              # schema, migrations, seed
packages/domain          # commands, state machines, guards, event types  ← only writer
packages/policy          # visibility engine, redaction, label_map, stage derivation
packages/workflow        # triggers T1–T19, timers, working-day calendar
packages/realtime        # hub, SSE, channel auth
packages/integrations    # accounting, notifier, storage, whatsapp
packages/ui              # shared components (use existing design tokens)
packages/dashboards      # metric queries/views
docs/                    # this pack
```

## Security & compliance
OWASP ASVS L2 baseline; CSRF; rate limiting; per-role export audit; PII encryption at rest for contacts, bank details; secrets via env; every policy decision unit-tested; no feature may read a table directly from a UI layer.
