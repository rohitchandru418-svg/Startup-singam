# 01 · Product Overview — Startup Singam

Source of truth: `Startup_Singam_2__1_.xlsx` (11 sheets). Where this pack and the spreadsheet disagree, the spreadsheet wins; log the conflict in `docs/09_OPEN_QUESTIONS.md`.

## What the product is
Startup Singam is a season-based program in which startups apply, are screened, prepared, assessed, matched with investors, pitched, selected by a committee, shot for a TV show, and then followed through deal closure, fund deployment, telecast promotion and success-fee collection. One platform serves **two external personas** (Founder, Investor) and **internal teams** (Startup Relations, Analyst, Investor Relations, Finance, Production, Legal, Marketing, Community, Super admin/Management).

## The central design idea
**One shared data source. Many permissioned views.**
- Every fact (an application, a verdict, a tranche, a signature) is stored **once**.
- Internal screens write to it. External screens are *projections* of the same records, filtered and relabelled by a visibility layer.
- When an internal user changes something that an external user is allowed to see, the external screen updates live. When an external user acts (uploads a document, picks a slot, marks a tranche sent), the internal queue updates live.
- Founder-facing stage names are **derived** from internal stages. They are never stored separately.

## Personas (11 sheets → 11 staff roles + 2 external)
| Group | Persona | Sheet | Login | Core job |
|---|---|---|---|---|
| External | Founder | Founder journey | Yes (one per startup) | Apply, respond, sign, upload, confirm, post |
| External | Investor | Investor journey | Yes (one per investor) | Register, verify, commit season amount, review IRRs, give verdicts, close deals, transfer funds |
| Internal | SR Relationship Manager (RM) | SR workflow | Yes | Owns startup steps 1–7; follow-up on 8–11 |
| Internal | Analyst | Analyst workflow | Yes | Evaluates redacted applications, 5 working days |
| Internal | IR Manager (IRM) | IR workflow | Yes | Owns investors and deals through closure |
| Internal | Finance (+ Finance lead) | Finance workflow | Yes | IRR, upfront fee, receipt/tranche verification, success fee, reconciliation |
| Internal | Production coordinator (+ Production head) | Production workflow | Yes | Handover, shoots, episode, edit |
| Internal | Legal | Legal workflow | Yes | Legal Q&A, MoU redraft, templates, DD, agreements, conditions |
| Internal | Marketing | Marketing workflow | Yes | Telecast schedule, promo assets, founder posting, announcements |
| Internal | Community | Community workflow | Yes | Member records, events, referrals, founder support |
| Internal | Super admin / Management | Super admin | Yes (CEO, directors, managing partners; any one can approve) | Approvals inbox, escalations, reassignment, policies, season setup, users |
| No login | Mentors, partners, committee members | Community / IR | **No** (v1) | Recorded as people; committee decisions are recorded by IR |

## Program lifecycle (two parallel tracks after the main shoot)
```
Profile → Application → Submitted → Internal screening → Pre-bootcamp → Analyst fit check → MoU
→ Document scrutiny (IRR) → Investor matching + virtual pitch → Pitch Day → Final selection
→ Upfront fee → AV shoot → Mock shoot → Main shoot
        ├── Track A: Telecast & promotion
        └── Track B: Deal closure (per investor) → Funds received (per tranche) → Success fee
→ Community
```

## Non-negotiable business rules (enforce in code, not just UI)
1. Founder sees a **verdict only** at screening (no score). At the fit check, founder sees only "In progress / Fit check done".
2. Investor **grade (L1–L4) is never shown** to the investor or founder.
3. **Interest is not money.** Analyst willingness/indicative amount and investor "indicative" amounts never count as commitment.
4. SR **cannot override** an analyst Reject.
5. A payment **screenshot never marks anything paid.** Only Finance verification against bank evidence does.
6. Success fee is calculated **only on verified received money**; one invoice per verified tranche; reversals reduce the fee base.
7. Analysts never see founder names or contacts — in screens, exports, or shared documents.
8. Production sees permitted business information only; Marketing sees approved publication information only. Investor remarks and deal documents are hidden from both.
9. Community membership **never** grants access to deal information.
10. IRRs are **view-only in-system for investors** (no download); every version is kept.
11. Founder profile is **reused every season**.
12. Investor grades, revised/withdrawn commitments, fee exceptions/discounts, waivers, refunds, disputes, extensions over 7 days need Super admin approval; **every approval has a 2-working-day deadline**.
