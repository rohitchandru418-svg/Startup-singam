# 03 · Domain Model (single shared schema)

All tables live in ONE PostgreSQL database. Every table has `id uuid`, `created_at`, `updated_at`, `created_by`, `updated_by`, `season_id` (where season-scoped) and soft-delete only. All state changes also write `audit_log` and emit a domain event (see doc 05).

## 1. Identity & access
- `user` (login: staff, founder, investor) · `user_role` (role, department) · `person` (one person, many roles — Community) · `organisation`
- `policy` + `policy_version` (key, value json, effective_from, approved_by): screening pass mark, eligibility rules, fee schedule, working-day calendar, SLA durations
- `season` (application window, fee schedule version, status) · `season_episode` · `season_committee_member` (person, no login) · `template` + `template_version` (MoU, Participation Agreement, NDA, Investment Commitment Letter, Startup Deal Acceptance Letter, Term Sheet; approved by super admin)

## 2. Startup side
- `startup` (reused across seasons; company, sector, stage, financials, founders[]) · `founder` (person link; one login per startup) · `startup_document`
- `application` (season_id, startup_id, status draft|submitted|locked, completeness %, missing_items json, rm_id, duplicate_of)
- `screening` (rm_id, 100-mark card: `screening_score` rows with criterion, score, comment, evidence_ref; verdict PROCEED|INFO_REQUIRED|HOLD|REJECT; reason; auto_held_at)
- `info_request` (target: founder; items[] exact text; due_at; status) — generic, reused by screening, IRR queries, verification
- `bootcamp_batch`, `bootcamp_enrolment` (invited, attended), `bootcamp_milestone` (process briefing, readiness sessions, MoU+fee briefing, questions answered), `action_item`; `preparation_complete` flag
- `analyst_assignment` (analyst_id, due_at = +5 WD, escalated_at) · `analyst_evaluation` (thesis fit, market, traction, business model/scalability, competitive positioning; willingness; indicative_amount; recommendation PROCEED|CONDITIONAL|HOLD|REJECT; reason; outstanding_concern) · `condition_task` (from conditional proceed; must clear before IRR handover)
- `mou` (version, status shared|qa_done|signed|negotiating|discontinued, shared_at, qa_due_wd4, sign_due_wd7, signed_copy_ref, commercial_schedule json {type percentage|fixed|slab, cap, eligible_funding, upfront_adjustment_allowed}, exceptions, signed_on, discontinue_reason, founder_email) · `legal_qa_log`
- `irr` (startup_id, status requested|accepted|gathering|in_review|awaiting_super_admin|approved|handed_to_ir|accepted_by_ir) · `irr_version` (file, version, approved_by) · `irr_query` (text verbatim, due_at, resolved_at) · `irr_share` (investor_id, version shared, date)

## 3. Investor side
- `investor` (category, entity, decision_maker, authorised_rep, sectors[], stages[], geography[], thesis, ticket_min/max, portfolio, availability, decision_timeline, source, referred_by, irm_id, status sourced|verified|graded|active) · `investor_agreement` (participation, nda; signed refs)
- `verification` (evidence, status in_progress|more_info|verified; eligibility rule results) · `grade` (L1–L4, dimension scores, evidence, review_date, status proposed|approved, reason on change) — **INTERNAL ONLY**
- `season_allocation` (investor_id, season_id, allocated, max_per_startup) — separate from commitments
- `pairing` (investor_id, startup_id, match_score, match_dimensions json, status suggested|circulated|accepted|declined, irr_version_shared, shared_at, response, questions, docs_requested, indicative_amount, next_action, next_action_due, pass_reason) — **each pairing its own record**
- `meeting` (type virtual_pitch|pitch_day, slot, proposed_by, investor_approved, founder_booked, attendance, minutes, minutes_ack_investor, minutes_ack_founder)
- `verdict` (pairing_id, round, value READY|NEXT|INFO|HOLD|PASS|NO_RESPONSE, entered_by (investor|irm_on_behalf), due_at) · `ready_to_invest_form` (amount, valuation_range, instrument, conditions, `is_indicative=true` always)
- `golden_pass` (pairing, issuer, issued_at; no minimum commitment) · `written_commitment` · `hni_followon_interest` (deadline)
- `committee_pack` (compiled snapshot) · `committee_decision` (startup_id, decision PROCEED|HOLD|REJECTED, conditions, approver, decided_at, re_review_at)

## 4. Money
- `fee_schedule_version` (supplied later — design config-driven) · `upfront_fee` (startup, season, turnover, financial_year, evidence, schedule_version, exception, amount, status requested|turnover_verified|approved|invoiced|proof_uploaded|part_paid|paid|overdue|disputed|waived|refunded, due_at (committee_decision+15d), original_due_at, extension_due_at)
- `extension_request` (reason, days, approver) · `invoice` (kind upfront|success, number, due_at, zoho_id, sync_status) · `payment_proof` (file, uploaded_by; **never marks paid**) · `receipt` (verified_by, bank_ref, amount, allocated_to_invoice, tds_amount)
- `commitment` (deal_id, investor_id, amount, status proposed|confirmed|revised|withdrawn, revision_reason, approved_by) — distinct from allocation and from indicative amounts
- `deal` (startup_id, investor_id, accountable_irm_id, closure_stage, thread_opened_at (48h), blocker, owner, next_action) · `deal_milestone` (type term_sheet|dd|agreements|pre_funding_conditions|funding, expected_date, completed_at) · `dd_task`, `dd_finding` (severity, status) · `agreement` (SHA/SSA/…, signatures) · `pre_funding_condition` (IP assignment, board resolution…) · `replacement_search`
- `tranche` (deal_id, scheduled_amount, scheduled_date, investor_reported_amount, utr, investor_proof, founder_confirmed_receipt, founder_proof, verified_amount, verified_on, verified_by, status, reversal_of)
- `success_fee` (tranche_id, base, rate/slab, cap, eligible?, discount, waiver, amount, invoice_id, status) — one per verified tranche · `tds_entry`, `form16a`, `credit_note`, `reconciliation` (balanced bool; GST; TDS pending)
- Five fee measures are **computed views**, never one column: `forecast_fee, fee_due, invoiced, collected, outstanding`.

## 5. Production & Marketing
- `handover_notice` (advance, at Proceed) · `handover_pack` (auto-assembled snapshot; IR approves; Production accepts) · `shoot` (type av|mock|main, date, location, coordinator_id, status) · `episode_allocation` · `investor_panel` · `shoot_document_requirement` (per signing event, not per filename) · `signing_event` (investor_commits_on_set, founder_accepts_deal; required doc, signed/uploaded, deadline) · `shoot_exception` (founder_no_show|investor_absent|deal_withdrawn|signature_refused|technical_failure) · `mock_readiness_item` · `main_shoot_record` (offers, accepted terms, lead/co split, conditions) · `asset_link` · `episode_edit` (status editing|awaiting_approval|approved)
- `telecast` (episode, air_date, broadcaster) · `promo_asset` (approval) · `founder_posting` (status Posted|Not posted, link — **no reach metrics**) · `feedback` (rating, text, routed_to_production) · `announcement` (wording, labelled announced|committed|verified_deployed, investor_approved_at)

## 6. Cross-cutting
- `task` / `work_item` (assignee, department, due_at, sla_state, source_entity) — **drives every queue and "what needs me today"**
- `approval` (type, raised_by, entity, due_at = +2 WD, decided_by, decision, reason)
- `escalation` · `reassignment` · `note` (internal, @mention) · `notification` · `communication_log` (email/WhatsApp opened-at) · `document` (versioned, storage ref, classification, redaction rules) · `audit_log` · `domain_event` (outbox)
- Community: `member`(=person view), `group`, `event`, `event_registration`, `event_feedback`, `referral` (chain stages; original source + later contributors separate), `support_request`

## 7. Key state machines (implement as explicit transition tables with guards)
**Application/Startup pipeline:** draft → submitted → screening → {info_required ⇄ screening | hold | rejected | proceed} → bootcamp → prep_complete → with_analyst → {analyst_reject (terminal, SR cannot override) | analyst_proceed | conditional_proceed (creates condition_task) | analyst_hold} → mou → irr → matching → virtual_pitch → pitch_day → committee → {proceed | hold | rejected} → upfront_fee → av_shoot (needs fee fully verified + handover accepted) → episode_allocated → mock → main_shoot → {telecast track ‖ deal track} → closed.
**MoU:** shared → qa_done(WD4) → {signed | negotiating → super_admin_approval → v2 shared (clock restarts) | discontinued}. 
**IRR:** requested → accepted → gathering → in_review → awaiting_super_admin → approved → handed_to_ir → ir_accepted.
**Upfront fee:** per field above; `paid` only via Finance receipt verification; on `paid` → auto handover pack.
**Pairing:** suggested → circulated(IRM approves) → accepted|declined → virtual_pitch → verdict → pitch_day → golden_pass/commitment → committee.
**Deal:** opened → thread_opened(≤48h) → term_sheet → dd → findings_resolved → agreements → pre_funding_conditions_met → funding(tranches) → closed | withdrawn → replacement_search.
**Tranche:** scheduled → investor_marked_sent → founder_confirmed → finance_verified | reversed.
