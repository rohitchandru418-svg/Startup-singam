# 02 · Personas, Journeys and Permissions

## A. External personas

### A1. Founder
**Mental model:** "Where am I, what do you need from me, by when, and who do I talk to?"
- One founder login per startup. Profile persists across seasons (stage 0).
- 20 stages (0–19). Steps 0–14 sequential; then **15 Telecast** runs in parallel with **16–18 Deals → Funds → Success fee**.
- Every step needing action shows: **what is needed, deadline, whom to contact**.

| # | Founder sees | Internal source | Founder action | Deadline shown | Contact |
|---|---|---|---|---|---|
| 0 | Profile | Startup record | Register, complete, update between seasons | — | SR |
| 1 | Application – draft | Application | Fill, save, resume. Idea stage skips financials. Shows % complete + what's missing | "Applications close in X days" | SR |
| 2 | Application – submitted | Formal submission | Locked; acknowledgement; RM assigned | — | SR |
| 3 | Internal review | Screening (100 marks) | Verdict only: Proceed / Information required (exact items) / On hold / Not selected. Respond to info required | Reply-by (7 days) | SR |
| 4 | Pre-bootcamp | Prep Bootcamp | Accept invite, attend, action items | Session dates | SR |
| 5 | Investment fit check | Analyst screening | None. "In progress" → "Fit check done" | — | SR |
| 6 | MoU | Startup MoU | Download; Legal Q&A WD4; Sign+upload / Negotiate (reason) / Not proceeding (reason) | WD7 countdown | SR, Legal |
| 7 | Document scrutiny | IRR | Checklist; team queries **verbatim**; upload documents | Per-query due | SR, Finance |
| 8 | Investor matching + virtual pitch | Matching + pitch | "Matched with N investors"; pick slots; attend; answer info requests; per-investor verdict: Ready to invest / Next stage / Information requested / On hold / Pass / No response | Slot dates | IR |
| 9 | Pitch Day | Pitch Day + Golden Pass | Pick 1:1 slots (after investor approves); outcome per investor: Golden Pass / Written commitment / No response / Pass | Pitch Day | IR |
| 10 | Final selection | Committee | Proceed / On hold / Not selected | — | Management |
| 11 | Upfront fee | Upfront fee workflow | Fee, turnover + FY basis, invoice, bank details; status: Proof uploaded – verifying / Paid / Part paid / Overdue / Extension approved. Upload proof; request extension (reason) | 15-day countdown | Finance |
| 12 | AV shoot | AV shoot | Confirm availability | Shoot date | Production |
| 13 | Mock shoot | Mock shoot | Readiness checklist | Shoot date | Production |
| 14 | Main shoot | Main shoot | Offers accepted, lead/co-investors, conditions, signed/outstanding docs; sign Startup Deal Acceptance Letter | Signing deadline | Production, IR |
| 15 | Telecast & promotion | Marketing | Episode/air date; approved posts; approved wording; post (submit link), mark done, feedback | Air date | Marketing |
| 16 | Deal closure (one card per investor) | Post-shoot closure | Term sheet, DD requests, agreements, conditions, expected date per milestone, withdrawal reason / replacement investor; upload DD docs, sign | Milestone dates | IR, Legal |
| 17 | Funds received (per investor, per tranche) | Deployment tracking | committed/received/pending; confirm receipt + upload bank statement | Tranche dates | IR, Finance |
| 18 | Success fee | Post-funding collections | Fee only on money actually received: base, rate, invoice; upload proof; enter TDS; upload Form 16A | Invoice due | Finance |
| 19 | Community | Community | Alumni, mentors, events, support requests | — | Community |

**Label mapping** (single `label_map` table/config, never hard-coded in components):
| Internal | Founder label |
|---|---|
| Proceed | Proceed |
| Information required | Information required |
| Hold / auto-Hold | On hold |
| Reject / Committee Rejected | Not selected |
| Analyst drafting | In progress |
| Analyst submitted | Fit check done |

### A2. Investor
**Mental model:** "How much have I committed, which startups need my decision, what blocks my money moving?"
- One login per investor. **Season meter on every screen:** allocated · committed · deployed · available.
- **No fees.** Grade hidden. Communication thread runs on email/WhatsApp; system records when it was opened.

| # | Investor sees | Action | Deadline |
|---|---|---|---|
| 0 | Express interest (short form, referred-by) | Register, log in | — |
| 1 | Investor profile | Category + entity, decision-maker, authorised rep, sectors, stages, geography, thesis, ticket size, portfolio, availability, decision timeline | — |
| 2 | Agreements (Participation + NDA; **no MoU**) | Sign and upload both | Sign-by |
| 3 | Verification: In progress / More information needed (exact items) / Verified | Answer queries, upload evidence | Reply-by |
| 4 | Season commitment | Confirm season amount + max per startup | — |
| 5 | Matches (5–6, match %) | Review IRR; accept/decline each | Respond-by |
| 6 | IRRs (view-only, versioned, date shared) | Read, ask questions, request docs, give indicative amount | — |
| 7 | Virtual pitches (5 min pitch + 5 min Q&A) | Approve slot, attend, acknowledge minutes, **verdict**: Ready to invest / Next stage / Information requested / Pass / No response. "Ready to invest" opens form: amount, valuation range, instrument, conditions — marked **indicative** | Verdict due |
| 8 | Pitch Day (team-proposed 1:1 slots; investor approves, then founder books; information memorandum; Golden Pass recorded by team) | Approve slots, attend, acknowledge minutes, follow-on interest | Pitch Day |
| 9 | Committee results — **only startups they showed interest in**: Proceed / On hold / Rejected | — | — |
| 10 | Pre-shoot confirmation (episode, shoot date, IRR 2-week rule, proposed commitment, valuation boundaries, decision parameters, briefing, documents) | Confirm commitment in writing; acknowledge briefing | 2 weeks before shoot |
| 11 | Main shoot (offers, accepted deal, lead/co split, conditions) | Sign Investment Commitment Letter | Signing deadline |
| 12 | Deal room (one per startup; 48h thread countdown; term sheet; DD progress; findings; agreements; pre-funding conditions; expected dates; revisions/withdrawals need reason) | Share term sheet, respond to DD, sign | 48h, then milestones |
| 13 | Fund transfers per tranche: scheduled, "you reported ₹X", "startup confirmed", verified, remaining | Mark tranche sent with UTR + proof | Tranche dates |
| 14 | Public announcement (announced vs committed vs deployed) | Approve wording | Before publication |
| 15 | Community | Join events, refer investors | — |

## B. Internal roles

Enum: `SUPER_ADMIN, SR_RM, ANALYST, IR_MANAGER, FINANCE, FINANCE_LEAD, PRODUCTION_COORDINATOR, PRODUCTION_HEAD, LEGAL, MARKETING, COMMUNITY`. A user may hold several roles. Super admin: "any one can approve; system records who".

| Role | Owns | View / follow-up only | Must NOT see |
|---|---|---|---|
| SR_RM | Startup steps 1–7 | Steps 8–11; lifecycle tracks | Investor grade; investor confidential remarks; cannot override analyst Reject |
| ANALYST | Evaluation queue (5 WD) | — | **Founder names/contacts** in screens, exports, docs; never contacts founders (via SR) |
| IR_MANAGER | Investors end to end; deals through closure (one accountable IRM per deal) | Startup 360; fee, shoot, receipt, success fee | — |
| FINANCE / FINANCE_LEAD | IRR, upfront fee, receipt + tranche verification, success fee, reconciliation. Lead approves standard fees + extensions ≤ 7 days | — | Does **not** do due diligence |
| PRODUCTION_COORDINATOR / HEAD | Handover, AV, mock, main shoot, post-shoot docs, edit. Head approves allocation, reviews edit | — | Investor confidential remarks; deal documents |
| LEGAL | Legal Q&A, MoU v2, templates, DD, agreements, pre-funding conditions | — | — |
| MARKETING | Telecast, promo assets, founder posting, announcements | — | Investor remarks; deal documents |
| COMMUNITY | Member records, events, referrals, founder support | — | **All deal info**, regardless of membership |
| SUPER_ADMIN | Approvals inbox, escalations, reassignment, policies, season setup, users/roles | Everything | — |

### Approvals (one inbox, 2 WD deadline, overdue flagged)
Investor grade (IR) · Revised/withdrawn commitment (IR) · MoU negotiation outcome (SR) · IRR final (Finance) · Fee exceptions/discounts (Finance) · Extensions >7d, waivers, refunds, disputes (Finance; lead approves ≤7d) · Mock shoot readiness (Production) · Episode edit (Production, proposed) · Legal template versions · Promo assets (Marketing) · Event budget (Community).

## C. Field-level visibility matrix
✔ full · ◐ redacted/derived · ✖ none. Each row becomes declarative policy entries (`resource, field, role, condition`) enforced on reads, writes, exports, search, notifications, realtime payloads and file downloads.

| Data class | Founder | Investor | SR | Analyst | IR | Finance | Production | Legal | Marketing | Community | Super |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Founder identity/contacts | own ✔ | ◐ per policy (see Open Q) | ✔ | **✖ redacted** | ✔ | ✔ | ✔ via handover | ✔ in deal | ◐ | ✔ member record | ✔ |
| Screening score/evidence | ✖ verdict only | ✖ | ✔ | ✖ | ◐ pack | ✖ | ✖ | ✖ | ✖ | ✖ | ✔ |
| Analyst evaluation, willingness, amount | ✖ | ✖ | ◐ recommendation | ✔ | ◐ pack | ✖ | ✖ | ✖ | ✖ | ✖ | ✔ |
| Investor grade | ✖ | ✖ | ✖ | ✖ | ✔ | ✖ | ◐ panel role | ✖ | ✖ | ✖ | ✔ approves |
| IRR | ✖ (checklist/queries only) | view-only, no download | ✔ | ◐ | ✔ | ✔ | ◐ | ✖ | ✖ | ✖ | ✔ |
| Investor verdict per startup | ✔ label | own | ✔ | ✖ | ✔ | ✖ | ✖ | ✖ | ✖ | ✖ | ✔ |
| Investor confidential remarks | ✖ | own | ✖ | ✖ | ✔ | ✖ | ✖ | ✖ | ✖ | ✖ | ✔ |
| Deal docs / term sheet | own deal | own deal | ◐ status | ✖ | ✔ | ◐ | ✖ | ✔ | ✖ | ✖ | ✔ |
| Upfront / success fee | own | ✖ | view | ✖ | view | ✔ | ◐ cleared? | ✖ | ✖ | ✖ | ✔ |
| Tranches | own deal | own | ◐ | ✖ | ✔ | ✔ | ✖ | ◐ conditions | ✖ | ✖ | ✔ |
| Shoot / episode | own | own deal | view | ✖ | view | ✖ | ✔ | ✖ | ◐ approved | ✖ | ✔ |
| Promo / announcement | own | own wording | view | ✖ | view | ✖ | ✖ | ✖ | ✔ | ✖ | ✔ |
