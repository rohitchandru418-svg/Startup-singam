# 04 · End-to-End Workflows, Handoffs, Automatic Triggers, Clocks

Format: **Trigger → who does what → output/gate → what each external persona sees → what is auto-triggered.**

## Part 1 · Startup track
| Step | Founder-visible stage | Internal owner | Gate / output | Auto-triggers |
|---|---|---|---|---|
| 1 New application | 2 Submitted | SR RM | Application in RM queue | RM auto-assigned; acknowledgement auto-sent; duplicate check links repeat applicants; lock application |
| 2 Screening (100 marks) | 3 Internal review | SR RM | Verdict + reason | Info required → 7-day clock → **auto-Hold** if no reply. No pass mark yet: RM decides, score guides |
| 3 Pre-bootcamp | 4 | SR RM | **Preparation complete** (attendance alone is not enough) | Invite batch; milestones; action items |
| 4 Send to analyst | 5 | SR RM | Analyst assigned from pool | **Redaction profile applied automatically**; 5-WD due; overdue → escalation |
| 4b Analyst evaluation | 5 "In progress" | Analyst | Recommendation Proceed/Conditional/Hold/Reject | Submit → SR notified; founder sees "Fit check done". Questions to founder go via SR as `info_request` — analyst never contacts founder |
| 5 SR reviews analyst | — | SR RM | Go to MoU or stop | Reject is final. Conditional → `condition_task` for SR, must clear **before IRR handover to IR** |
| 6 MoU | 6 | SR + Legal (+ Super admin if negotiate) | Signed MoU | Share → clock; Legal Q&A due WD4; sign due WD7. Negotiate → escalate → Super admin approves terms → Legal redrafts v2 → SR shares → clock restarts. Discontinue → record founder email + reason |
| 7 IRR | 7 Document scrutiny | SR raises; Finance/IRR builds; IR accepts | Approved IRR | MoU signed → automatic IRR request alert to Finance; queries posted to founder **verbatim** with SR cc'd; Finance lead review; Super admin final; all versions kept; alert if not with investors 2 weeks before shoot |
| 8 Matching & virtual pitch | 8 | IR | Verdict per pairing | See Part 2 |
| 9 Pitch Day | 9 | IR | Golden Pass/commitments recorded | See Part 2 |
| 10 Committee | 10 | IR compiles pack & records; Management decides | Proceed/Hold/Rejected | **On Proceed (no manual step):** create upfront fee request (15-day clock), send Production advance notice, inform SR |
| 11 Upfront fee | 11 | Finance (SR chases) | Paid | Turnover verified → fee calc+approve → invoice (Zoho sync) → founder notified → proof uploaded → Finance verifies vs bank → **paid → auto-assemble AV handover pack** → IR approves → Production accepts |
| 12–14 Shoots | 12 AV, 13 Mock, 14 Main | Production | Deal confirmed | AV only after full upfront fee. Episode allocation (Production + IR; Head approves) → IR builds panel → pre-shoot docs per signing event → mock (Super admin final readiness) → main (captures signatures; exceptions logged) → deal confirmed → IR takes over |
| 15 Telecast | 15 | Marketing | Posting complete | Episode approved (Production head; Super admin proposed) → air date; founder notified; promo assets approved by Super admin; founder posts and submits link; feedback collected → routed to Production |
| 16 Deal closure | 16 (card per investor) | IR (accountable IRM) + Legal + Finance + external advisors | Signed deal, conditions met | Thread opened ≤48h and logged; DD tasks owned by Legal; findings by severity; definitive agreements; pre-funding conditions (IR confirms); withdrawals/revisions need reason + Super admin approval; replacement-investor search |
| 17 Funds | 17 | IR chases; Finance verifies | Tranche verified | Investor marks sent (UTR+proof) or IRM records; founder confirms receipt + bank statement; Finance verifies; **verified → success-fee task auto-created** |
| 18 Success fee | 18 | Finance (SR chases) | Collected | Calculate on verified money only → lead review → one invoice per tranche → founder pays net, enters TDS → allocate cash+TDS → reconcile; Form 16A reminders; credit note on reversal; closed only when balanced + TDS certificates in |
| 19 Community | 19 | Community | — | — |

## Part 2 · Investor track
| Step | Investor-visible | Internal owner | Rules |
|---|---|---|---|
| 1 Express interest/referral | 0 | IR (IRM auto-assigned) | Referral links to Community record, no duplicates |
| 2 Record + verification + agreements | 1–3 | IRM; Legal for docs | Eligibility rules are **policies** (configurable). Agreements = Participation + NDA, no MoU. Founder-journey order shows Agreements before Verification; internal flow verifies then collects signatures — **show both as parallel checklist items; gate Matching on both complete** |
| 3 Grading | hidden | IRM proposes; Super admin approves | L1–L4 sets engagement + panel role; review date; changes need reason |
| 4 Season allocation | 4 | IRM records; investor confirms | Allocation ≠ commitment |
| 5 Receive IRRs | — | IRM accepts handover | Startups become matchable |
| 6 Matching | 5–6 | System suggests (sector, stage, cheque, geography, thesis, grade, unused allocation); **IRM approves circulation** | 5–6 per investor; flag startups with <3 matches. IRR shared view-only, versioned |
| 7 Virtual pitch | 7 | IRM schedules; investor approves slot | 5+5 min; verdict by investor or IRM on behalf; Ready → indicative form |
| 8 Pitch Day | 8 | IRM maps, proposes slots → investor approves → founder books | Info memorandum; Golden Pass (no min commitment) recorded by team; HNI follow-on interest with deadline |
| 9 Committee pack | 9 | IRM compiles; Committee decides | Investor sees result only for startups they showed interest in |
| 10 Pre-shoot | 10 | IRM + Production | 2-week IRR rule; written proposed commitment; valuation boundaries; decision parameters; briefing |
| 11 Main shoot | 11 | Production captures; IRM oversees | Investment Commitment Letter signed on paper → uploaded |
| 12–13 Deal room & funds | 12–13 | IRM | As above |
| 14 Announcement | 14 | Marketing drafts; **investor approves** (founder not needed) | Labels announced / committed / verified deployed; flag claim where announced ≠ deployed |
| 15 Community | 15 | Community | — |

## Part 3 · Automatic triggers catalogue (implement each as an event handler with an idempotency key)
| # | Event | Handler effect |
|---|---|---|
| T1 | `application.submitted` | assign RM, send ack, duplicate check, create screening task |
| T2 | `screening.info_required` | create founder `info_request`, 7-day timer |
| T3 | `info_request.expired` (screening) | set verdict HOLD (auto), notify both |
| T4 | `preparation.complete` | enable "Send to analyst" |
| T5 | `analyst.assigned` | apply redaction; due +5 WD |
| T6 | `analyst.overdue` | escalation to Super admin |
| T7 | `analyst.submitted` | notify SR; founder status "Fit check done" |
| T8 | `mou.shared` | start WD4 Legal Q&A task, WD7 deadline |
| T9 | `mou.signed` | create IRR request + Finance alert |
| T10 | `irr.approved` | handover to IR (IR accept task) |
| T11 | `committee.proceed` | upfront fee request + 15-day clock; Production advance notice; SR inform |
| T12 | `upfront_fee.receipt_verified (full)` | assemble handover pack → IR approval task → Production acceptance task |
| T13 | `shoot.main.deal_confirmed` | open deal(s); assign accountable IRM; 48h thread clock; SR follow-up tasks |
| T14 | `tranche.verified` | create success-fee task |
| T15 | `tranche.reversed` | reverse deployed, reduce fee base, credit note if invoiced |
| T16 | `episode.approved` | Marketing telecast task |
| T17 | `approval.created` | due +2 WD; overdue → dashboard |
| T18 | `irr.not_with_investors` at T-14d before shoot | alert Finance, IR, SR |
| T19 | `invoice.due_passed` | mark overdue, ageing from ORIGINAL due date |

## Part 4 · Clocks (all in working days per `working_day_calendar` policy unless noted)
Info required 7 days (calendar) · Analyst 5 WD · MoU Q&A WD4 · MoU sign WD7 · Upfront fee 15 days from committee decision (calendar) · Extension ≤7d Finance lead, >7d Super admin; extension adds new due date and **keeps original** · Overdue ageing buckets 0–15, 15–30, 30+ from original due date · IRR with investors ≥ 2 weeks before shoot · Investor pre-shoot confirmation 2 weeks before shoot · Deal thread ≤48h · Approvals 2 WD · Post-shoot signature collection same day/24h (**to confirm**).

## Part 5 · Shoot-day exceptions
Founder no-show → reschedule, inform SR · Investor absent → adjust panel, inform IR · Deal withdrawn on set → reason, IR replacement search · Signature refused → escalate IR + Super admin · Technical failure → reshoot.
