# 05 · Shared Data Source, Visibility Layer and Live Sync

## Principle
One PostgreSQL database = the only source of truth. No portal has its own copy. No syncing jobs between "internal" and "external" data stores — there is nothing to sync, only **projections**.

```
 Internal UI ─┐                                 ┌─► Founder portal (SSE)
 Founder UI ──┤► Command API ► Domain service ► │
 Investor UI ─┘   (authz)      (guards+state)   ├─► Investor portal (SSE)
                                  │             └─► Internal dashboards/queues (SSE)
                                  ▼
            PostgreSQL (entities + audit_log + domain_event outbox)
                                  │
                     Outbox dispatcher ─► Handlers (triggers T1–T19, notifications, Zoho, email/WhatsApp)
                                  │
                         Realtime hub ─► per-user channel, payload filtered by Visibility layer
```

## Layers (build in this order)
1. **Domain services** — only place that mutates state. Each command: authorise → validate state-machine guard → write → append `audit_log` → insert `domain_event` in the **same transaction** (transactional outbox).
2. **Visibility layer (policy engine)** — `visible(role, resource, field, context)`. Applied to: API reads, list queries (row filters), search, CSV/PDF exports, file downloads, notification text, realtime payloads, email templates. Implement as serializers/"views" per audience: `FounderView`, `InvestorView`, `AnalystView`, `ProductionView`, `MarketingView`, `CommunityView`, `InternalFullView`. Never filter in the React component.
3. **Label/Stage projection** — `deriveFounderStage(startup)` and `deriveInvestorStage(investor, pairing)` compute stage + label + next action + deadline + contact from internal state. Founder 20-stage journey and investor 16-stage journey are *computed*.
4. **Realtime hub** — Server-Sent Events (default) or WebSocket. Channels: `user:{id}`, `startup:{id}`, `investor:{id}`, `deal:{id}`, `queue:{dept}`, `dashboard:{dept}`. Subscription authorised by the same policy engine. Event payload = **minimal invalidation message** `{entity, id, version, changedFields[]}` (changed field names filtered by visibility); client refetches via the normal API, so redaction cannot be bypassed.
5. **Optimistic concurrency** — `version` column on mutable entities; UI shows "updated by the team just now — review" if a conflict happens.
6. **Notifications** — in-app + email (+ WhatsApp adapter). Text composed from the audience view only. Opened-at recorded for the investor/founder thread.

## Two-way sync examples (acceptance scenarios — each must have an integration test)
| # | Actor action | Shared record | Who sees it instantly | As what |
|---|---|---|---|---|
| S1 | RM records verdict "Reject" with score 41 | `screening` | Founder: stage 3 "Not selected" (no score). Super admin dashboard counters. | label_map |
| S2 | RM sets Information required with 2 items | `info_request` | Founder: checklist with the exact 2 items + reply-by date; action badge | verbatim |
| S3 | Founder uploads items | `info_request`, `document` | RM queue item moves to "Response received" | internal |
| S4 | Analyst submits Proceed with willingness ₹X | `analyst_evaluation` | Founder: "Fit check done" only. SR: recommendation. Investor: nothing | redacted |
| S5 | Legal posts MoU v2 after approval | `mou` v2 | Founder: new MoU to download, countdown restarts | |
| S6 | Finance queries "upload MCA document" | `irr_query` | Founder: checklist item with exact text; SR cc'd | verbatim |
| S7 | Founder uploads proof | `payment_proof` | Finance "Receipts to check"; founder status "Proof uploaded – verifying" (NOT Paid) | |
| S8 | Finance verifies receipt (full) | `receipt`,`upfront_fee` | Founder "Paid"; Production handover pack appears for IR approval; SR dashboard % collected | |
| S9 | IRM approves match circulation | `pairing` | Investor: new match with % and IRR (view-only); Founder: "Matched with N investors" | |
| S10 | Investor submits verdict Ready to invest + indicative form | `verdict` | Founder: "Ready to invest" per investor (no amount); IRM sees amount marked indicative | |
| S11 | IRM proposes Pitch Day slots → investor approves | `meeting` | Founder can then book from approved slots only | |
| S12 | IR records committee Proceed | `committee_decision` | Founder "Proceed"; investors who showed interest see Proceed; Finance fee request; Production advance notice | |
| S13 | Production records accepted deal on set | `main_shoot_record` | Founder + investor see offers/lead-co split/conditions; IR deals created | |
| S14 | Investor marks tranche sent (UTR+proof) | `tranche` | Founder: "Investor reported ₹X — confirm receipt"; Finance verification queue | |
| S15 | Founder confirms receipt + bank statement | `tranche` | Investor: "startup confirmed receipt"; Finance can verify | |
| S16 | Finance verifies tranche | `tranche`,`success_fee` | Investor: verified; Founder: funds received; success fee task; season meter "deployed" updates | |
| S17 | IRM revises/withdraws commitment (reason) | `commitment`,`approval` | Super admin inbox; once approved, founder sees withdrawal reason / replacement | |
| S18 | Marketing drafts announcement | `announcement` | Investor approval task with labelled figures; founder sees only final published wording | |
| S19 | Founder submits post link | `founder_posting` | Marketing + SR dashboards | |
| S20 | Super admin reassigns startup RM→RM | `application.rm_id` | New RM queue; old RM loses; founder contact name updates | |

## Files and documents
Single `document` table + object storage (S3-compatible / local MinIO). Each doc has `classification` and `redaction_profile`. Downloads go through a signed, audited endpoint that re-checks policy. IRR for investors: stream rendered pages (images/PDF.js) with **no download/print link**, watermark with investor id + timestamp. Analyst exports: run through redaction pipeline.

## Data integrity rules
Money fields `numeric(18,2)`, currency INR default; never float. Fee numbers are views. Every approval/override stores who + when + reason. Soft deletes only. Idempotent handlers. UTC in DB, display in `Asia/Kolkata`.
